declare namespace Cypress {
    interface Chainable<Subject> {
        
  }
}