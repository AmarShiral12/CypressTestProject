describe('Checkbox Tests', ()=>{

    it('check_all_checkboxes', ()=>{
            cy.visit('http://automationpractice.com/index.php')
            cy.contains('Women').click()
            cy.get('.checkbox').check().parent().should('have.class','checked')
    
      })
      it.skip('uncheck_all_checkboxes', ()=>{
        cy.visit('http://automationpractice.com/index.php')
        cy.contains('Women').click()
        cy.get('.checkbox').check().parent().should('have.class','checked')
        cy.get('.checkbox').uncheck().parent().should('not.have.class','checked')
    })
    it.skip('check_first_checkbox', ()=>{
        cy.visit('http://automationpractice.com/index.php')
        cy.contains('Women').click()
        cy.get('.checkbox').first().check().parent().should('have.class','checked')
        
    })
    it.skip('check_first_checkbox', ()=>{
        cy.visit('http://automationpractice.com/index.php')
        cy.contains('Women').click()
        cy.get('#layered_id_attribute_group_2').check().parent().should('have.class','checked')
        
    })
    
    })